# notifier

## To run project
- configure database in hibernate.cfg.xml
- add your custom css and js file in src\main\webapp\resources\
- To run project mvn tomcat7:run-war 
